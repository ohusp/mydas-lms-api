<?php
   // //////////////// SEARCH FOR THIS ///////////////////////////////
 return[
 	// ////////////// Files //////////////////////////////////////////////
   //  'file_path1' => "/images/uploads/",
   //  'file_path2' => "/images/uploads/",
   //  online file path
    // 'file_path1' => "/images/uploads/",
    // 'file_path2' => "http://localhost:8000/images/uploads/",

    // // 'verification_file' => "http://localhost:3000/images/uploads/",
    // // "verification_file" => "C:\\xampp\htdocs\uk-lms\public/images/uploads/",
    // "verification_file" => "D:\Fontend-Projects\mydas-dashboard\public/images/uploads/",
    // 'api_baseURL' => "http://localhost:8000/api/",
    // 'client_baseURL' => "http://localhost:3000/",


    // ////////////////ONLINE ///////////////////////////////////////
    'file_path1' => "/images/uploads/",
    'file_path2' => "https://mydas-dashboard.brickpine.com/backend/images/uploads/",
    "verification_file" => "https://mydas-dashboard.brickpine.com/backend/images/uploads/",
    'api_baseURL' => "https://mydas-dashboard.brickpine.com/backend/api/",
    'client_baseURL' => "https://mydas-dashboard.brickpine.com/",
 ];