<?php
   // //////////////// SEARCH FOR THIS ///////////////////////////////
 return[
 	// ////////////// LOCAL //////////////////////////////////////////////
    'file_path1' => "D:\Fontend-Projects\mydas-dashboard\public/backend/images/uploads/",
    'file_path2' => "backend/images/uploads/",

    // 'verification_file' => "http://localhost:3000/images/uploads/",
    // "verification_file" => "C:\\xampp\htdocs\uk-lms\public/images/uploads/",
    "verification_file" => "D:\Fontend-Projects\mydas-dashboard\public/images/uploads/",
    'api_baseURL' => "http://localhost:8000/api/",
    'client_baseURL' => "http://localhost:3000/",


    // ////////////////ONLINE ///////////////////////////////////////
    // 'file_path1' => "/images/uploads/",
    // 'file_path2' => "backend/images/uploads/",
    // "verification_file" => "images/uploads/",
    // 'api_baseURL' => "https://mydas-dashboard.brickpine.com/backend/api/",
    // 'client_baseURL' => "https://mydas-dashboard.brickpine.com/",
 ];