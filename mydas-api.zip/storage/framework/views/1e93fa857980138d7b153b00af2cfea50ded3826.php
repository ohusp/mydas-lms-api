<?php $__env->startComponent('mail::message'); ?>
# <?php echo e($emailDetails['title']); ?>

Hello <?php echo e($emailDetails['first_name']); ?> <br>
Welcome to Digital Innovation and Skills Hub.<br><br>
DISH is an e-learning platform developed to provide access to youth and women to develop employment skills. Through DISH, online short certificate courses of 3 months are created and made available. The courses increase the employability of youth and women because they link to key emerging sectors in employment and contribute to stability, peace and resilience.
   
<?php $__env->startComponent('mail::button', ['url' => $emailDetails['url']]); ?>
Login
<?php if (isset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e)): ?>
<?php $component = $__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e; ?>
<?php unset($__componentOriginalb8f5c8a6ad1b73985c32a4b97acff83989288b9e); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

If you have any issues logging in with your new password please contact us elearning.project@kiu.ac.ug 

Thanks,

<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?><?php /**PATH C:\xampp\htdocs\uk-lms-api\resources\views/emails/welcomeMail.blade.php ENDPATH**/ ?>