<tr>
<td class="header">
<a href="<?php echo e($url); ?>" style="display: inline-block;">
<?php if(trim($slot) === 'DISH'): ?>
<img src="https://codeesa.kiu.ac.ug/images/logos/DISH%20Logo(3).png" class="logo" alt="Digital Innovation and Skills Hub Logo"><br>
<?php echo e($slot); ?>

<?php else: ?>
<?php echo e($slot); ?>

<?php endif; ?>
</a>
</td>
</tr>
<?php /**PATH C:\xampp\htdocs\uk-lms-api\resources\views/vendor/mail/html/header.blade.php ENDPATH**/ ?>