[<?php echo e($slot); ?>](<?php echo e($url); ?>)
<?php /**PATH C:\xampp\htdocs\uk-lms-api\resources\views/vendor/mail/text/header.blade.php ENDPATH**/ ?>